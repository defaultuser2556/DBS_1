import boto3
import json
import jinja2


def template(file, image_id, instance_type, key_name):
    with open(file) as f:
        jinja2_template = f.read()
    json_template = (
        jinja2.Environment(loader=jinja2.BaseLoader())
        .from_string(jinja2_template)
        .render(imageid=image_id, instancetype=instance_type, keyname=key_name)
    )
    return json_template


def test(a, b, c):
    return a


def handler(event, context):
    

    image_id = event['ImageId']
    instance_type = event['InstanceType']
    key_name =  event['KeyName']

    # return test(image_id, instance_type, key_name)
    # # test(image_id, instance_type, key_name)


    cf = boto3.client('cloudformation', region_name='eu-central-1')
    stack = cf.create_stack(
        StackName = "ec2stack",
        DisableRollback = True,
        TemplateBody = template("ec2_stack.j2", image_id, instance_type, key_name),
        Capabilities=["CAPABILITY_NAMED_IAM"],
    )


    return stack["StackId"]

